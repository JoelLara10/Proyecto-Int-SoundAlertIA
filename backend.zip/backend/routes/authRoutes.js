require('dotenv').config();
const express = require('express');
//const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const bcrypt = require('bcryptjs');
const User = require('../models/User'); // Asegúrate de importar correctamente el modelo User
const { registerUser } = require('../controllers/userController'); // Asegúrate de importar la función de registro

const router = express.Router();

// Middleware para verificar edad
const verificarEdad = (req, res, next) => {
    const { fechaNacimiento } = req.body;
    const cumple = new Date(fechaNacimiento);

    if (isNaN(cumple)) return res.status(400).json({ message: 'Fecha de nacimiento inválida.' });

    const hoy = new Date();
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const mes = hoy.getMonth() - cumple.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < cumple.getDate())) {
        edad--;
    }

    if (edad < 18) {
        return res.status(400).json({ message: 'Debes ser mayor de 18 años para registrarte.' });
    }

    next();
};

// Ruta para registrar un nuevo usuario
router.post('/register', verificarEdad, registerUser); // Agrega el middleware de verificación de edad antes de registrar al usuario

// Ruta para obtener todos los usuarios
router.get('/usuarios', async (req, res) => {
  try {
      const usuarios = await User.find();  // Encuentra todos los usuarios en la base de datos
      res.json(usuarios);  // Devuelve los usuarios en formato JSON
  } catch (error) {
      res.status(500).json({ msg: 'Error al obtener los usuarios' });
  }
});

// Login con bloqueo después de 3 intentos fallidos
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        let user = await User.findOne({ email });
        if (!user) return res.status(400).json({ msg: 'Credenciales incorrectas' });

        // Verificar si el usuario está bloqueado
        if (user.bloqueo_hasta && new Date() < user.bloqueo_hasta) {
            return res.status(403).json({ msg: 'Cuenta bloqueada. Inténtalo más tarde.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            user.intentos += 1;

            // Bloquear cuenta si ha fallado 3 veces
            if (user.intentos >= 3) {
                user.bloqueo_hasta = new Date(Date.now() + 3 * 60 * 1000); // 3 minutos de bloqueo
            }

            await user.save();
            return res.status(400).json({ msg: 'Credenciales incorrectas' });
        }

        // Restablecer intentos fallidos si inicia sesión correctamente
        user.intentos = 0;
        user.bloqueo_hasta = null;
        await user.save();

        const payload = { userId: user.id, rol: user.rol };
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.json({ token });
    } catch (error) {
        res.status(500).json({ msg: 'Error en el servidor' });
    }
});

module.exports = router;


// Recuperación de contraseña
router.post('/recuperar', async (req, res) => {
    const { email } = req.body;
    try {
        const usuario = await User.findOne({ email });
        if (!usuario) return res.status(400).json({ msg: 'El correo no existe' });

        const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, { expiresIn: '15m' });

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: { user: process.env.EMAIL, pass: process.env.EMAIL_PASS }
        });

        await transporter.sendMail({
            from: process.env.EMAIL,
            to: email,
            subject: 'Recuperación de contraseña',
            text: `Usa este token para cambiar tu contraseña: ${token}`
        });

        res.json({ msg: 'Correo de recuperación enviado' });
    } catch (error) {
        res.status(500).json({ msg: 'Error en el servidor', error });
    }
});

module.exports = router;
