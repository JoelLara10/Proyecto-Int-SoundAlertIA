const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const nodemailer = require('nodemailer');
require('dotenv').config();

// Registro de usuario
router.post('/register', async (req, res) => {
  console.log("Datos recibidos:", req.body); // Verifica los datos recibidos
  const { nombre, email, password, fechaNacimiento, rol } = req.body;

  if (!fechaNacimiento) {
      return res.status(400).json({ msg: "Fecha de nacimiento es requerida" });
  }

  console.log("Fecha de nacimiento procesada:", fechaNacimiento); // Confirma qué se está enviando

  if (!verificarEdad(fechaNacimiento)) {
      return res.status(400).json({ msg: "Debes ser mayor de 18 años" });
  }

  try {
      let usuario = await User.findOne({ email });
      if (usuario) return res.status(400).json({ msg: "El correo ya está en uso" });

      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);

      usuario = new User({ nombre, email, password: hashedPassword, fechaNacimiento, rol });
      await usuario.save();

      res.status(201).json({ msg: "Usuario registrado correctamente" });
  } catch (error) {
      console.error("Error en el servidor:", error); // Mostrará el error en consola
      res.status(500).json({ msg: "Error en el servidor" });
  }
});



// Inicio de sesión
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        let user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ msg: 'Credenciales incorrectas' });
        }

        // Verificar si el usuario está bloqueado
        if (user.bloqueo_hasta && new Date() < user.bloqueo_hasta) {
            return res.status(403).json({ msg: 'Cuenta bloqueada. Inténtalo más tarde.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            user.intentos += 1;

            // Bloquear cuenta si ha fallado 3 veces
            if (user.intentos >= 3) {
                user.bloqueo_hasta = new Date(Date.now() + 3 * 60 * 1000); // 3 minutos de bloqueo
            }

            await user.save();
            return res.status(400).json({ msg: 'Credenciales incorrectas' });
        }

        // Restablecer intentos fallidos si inicia sesión correctamente
        user.intentos = 0;
        user.bloqueo_hasta = null;
        await user.save();

        const payload = { userId: user.id, rol: user.rol };
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.json({ token });
    } catch (error) {
        res.status(500).json({ msg: 'Error en el servidor' });
    }
};
