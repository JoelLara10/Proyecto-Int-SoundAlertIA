require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet'); // Agregar helmet
const authRoutes = require('./routes/authRoutes'); 

const app = express();

// Usar helmet para aplicar políticas de seguridad
app.use(helmet());

// Configuración de middleware
app.use(express.json());
app.use(cors());

// Configuración de rutas
app.use('/api/auth', authRoutes);

// Conexión a la base de datos
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB conectado'))
    .catch(err => console.log(err));

// Rutas de la API
app.use('/api/auth', require('./routes/authRoutes'));

// Iniciar el servidor
app.listen(5000, () => console.log('Servidor corriendo en el puerto 5000'));
